-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: assignment3352
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `e_sports_orgs`
--

DROP TABLE IF EXISTS `e_sports_orgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `e_sports_orgs` (
  `name` varchar(75) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `e_sports_orgs`
--

LOCK TABLES `e_sports_orgs` WRITE;
/*!40000 ALTER TABLE `e_sports_orgs` DISABLE KEYS */;
INSERT INTO `e_sports_orgs` VALUES ('100 Thieves'),('9z Team'),('Afreeca Freecs'),('AGO Esports'),('ahq e-Sports Club'),('All Gamers'),('Alliance'),('Astralis'),('Atlanta FaZe'),('Atlanta Reign'),('Bacon Time'),('beastcoast'),('BIG'),('Bigetron eSports'),('Black Dragons e-Sports'),('BOOM Esports'),('Buriram United Esports'),('CDEC Gaming'),('Chaos Esports Club'),('CJ Entus'),('Cloud9'),('COGnitive Gaming'),('compLexity Gaming'),('Cooler Esport'),('Counter Logic Gaming'),('Dallas Empire'),('Dallas Fuel'),('DAMWON Gaming'),('DarkZero Esports'),('Denial Esports'),('DetonatioN'),('DRX'),('Echo Fox'),('EDward Gaming'),('EHOME'),('Elevate'),('ENCE eSports'),('Epsilon eSports'),('eStar Gaming'),('eUnited'),('Evil Geniuses'),('EVOS Esports'),('Falcons Esports'),('FaZe Clan'),('Flash Wolves'),('FlipSid3 Tactics'),('Fnatic'),('forZe'),('Four Angry Men'),('FunPlus Phoenix'),('FURIA Esports'),('G2 Esports'),('Gambit Esports'),('GamersOrigin'),('Gank Gaming'),('Gen.G Esports'),('Ghost Gaming'),('Guild Esports'),('HellRaisers'),('Hero JiuJing'),('Heroic'),('Immortals'),('Incredible Miracle'),('Infamous'),('Infantry Clan'),('Invictus Gaming'),('J Team'),('JD Gaming'),('Jin Air Green Wings'),('Keen Gaming'),('KT Rolster'),('Kungarna'),('Lazarus'),('LeStream Esport'),('LGD Gaming'),('London Spitfire'),('Los Angeles Gladiators'),('Los Angeles Thieves'),('LOUD'),('Luminosity Gaming'),('MAD Lions'),('Meet Your Makers'),('Method'),('MIBR'),('Millenium'),('Mineski'),('Misfits'),('MOUZ'),('MVP'),('Natus Vincere'),('New York Excelsior'),('New York Subliners'),('Newbee'),('NewHappy'),('Nigma Galaxy'),('Ninjas in Pyjamas'),('North'),('Nova eSports'),('NRG Esports'),('OG'),('OMG'),('OpTic Gaming'),('paiN Gaming'),('Paris Saint-Germain Esports'),('PENTA Sports'),('Philadelphia Fusion'),('Pittsburgh Knights'),('Qiao Gu Reapers'),('Qing Jiu Club'),('Quincy Crew'),('Red Bull eSports'),('Regans Gaming'),('REJECT'),('Renegades'),('Rex Regum Qeon'),('Rise Nation'),('Rogue'),('Rogue Warriors'),('ROX Gaming'),('Royal Never Give Up'),('Russian National Team'),('Samsung'),('San Francisco Shock'),('SCARZ'),('Sentinels'),('Seoul Dynasty'),('Shanghai Dragons'),('Six Two Eight'),('SK Gaming'),('Solary'),('Spacestation Gaming'),('Splyce'),('StarTale'),('Susquehanna Soniqs'),('T1'),('Taipei Assassins'),('Talon Esports'),('Team Alternate'),('Team Aster'),('Team BDS'),('Team Dignitas'),('Team DK'),('Team Empire'),('Team Envy'),('Team Flash'),('Team Kinguin'),('Team LDLC.com'),('Team Liquid'),('Team Queso'),('Team Reciprocity'),('Team Secret'),('Team SMG'),('Team SoloMid'),('Team Spirit'),('Team Weibo'),('Tempo Storm'),('The Chosen'),('Thunder Awaken'),('ThunderTalk Gaming'),('Tianba'),('TnC Gaming'),('Tong Jia Bao Esports'),('Top Esports'),('Toronto Ultra'),('Tribe Gaming'),('Tundra Esports'),('Turnso Gaming'),('TyLoo'),('V Gaming'),('Vega Squadron'),('Vici Gaming'),('Virtus.pro'),('Vitality'),('Wings Gaming'),('Wolves Esports'),('World Elite'),('Yoshimoto'),('Zenith E-Sports'),('ZETA DIVISION');
/*!40000 ALTER TABLE `e_sports_orgs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25 18:44:50
